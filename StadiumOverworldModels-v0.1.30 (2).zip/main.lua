-- Pokemon Stadium Overworld Models
--
-- Normal gen1recomp companion mod for Dramatic Shape.  This file does not
-- contain any Pokemon Stadium assets.  It reuses Dramatic Shape's Stadium
-- model packs after the player has built them from their own compatible ROM.
local mod = ...

local ds = mod.find("DRAMATIC_SHAPE")
assert(ds and ds.exports and ds.exports.lib,
  "STADIUM_OVERWORLD_MODELS: Dramatic Shape must be installed, enabled, and loaded first")

local BaseV = ds.exports.lib
assert(type(BaseV.require) == "function",
  "STADIUM_OVERWORLD_MODELS: Dramatic Shape did not export its library loader")

local function loadLocal(rel, arg)
  local source, readErr = mod:read(rel)
  assert(source, ("STADIUM_OVERWORLD_MODELS: missing %s: %s")
    :format(rel, tostring(readErr)))
  local chunk, err = load(source, "@" .. mod.path .. "/" .. rel)
  assert(chunk, ("STADIUM_OVERWORLD_MODELS: %s did not compile: %s")
    :format(rel, tostring(err)))
  return chunk(arg)
end

-- Load our configuration first, then make a tiny namespace that delegates all
-- Dramatic Shape modules to Dramatic Shape while intercepting our own config.
local Config = loadLocal("lib/OverworldStadiumConfig.lua", BaseV)
local PokemonHeights = loadLocal("lib/PokemonHeights.lua", BaseV)
local PokemonLocomotion = loadLocal("lib/PokemonLocomotion.lua", BaseV)

-- Put Stadium ROM selection inside THIS MOD'S Mod Manager -> Options screen.
-- The manifest also ships options.lua so Gen1Recomp exposes an OPTIONS button
-- for this mod.  StadiumRomMenu converts the STADIUM ROM FILE row into a real
-- Android file-picker action (A/Confirm, Left, or Right all open the system Files picker).
local RomMenuV = { require = BaseV.require }
local StadiumRomMenu = loadLocal("lib/StadiumRomMenu.lua", RomMenuV)
local managerOptionsInstalled = StadiumRomMenu.installModManagerOptions(mod)

-- Compatibility fallback only for much older builds without per-mod options.
-- On current builds this never runs, so the ROM row lives only under this
-- mod's own Options screen rather than the game's general OPTIONS menu.
if not managerOptionsInstalled then
  StadiumRomMenu.installOptionsHook(mod)
end

-- Yellow's stock follower controller normally exists only while a healthy
-- Pikachu is somewhere in the party. For this add-on the entity is our
-- generic first-party follower, so keep the STOCK controller/pathing alive
-- whenever party slot #1 exists. We do this without replacing its movement
-- code: during only the controller's private spawn check we expose a temporary
-- healthy Pikachu proxy. Bike/surf/event gates are still enforced by Yellow.
local function installFirstPartyFollowerSpawnPatch()
  if not Config.firstPartyFollower then return end

  local ok, Follower = pcall(require, "src.world.PikachuFollower")
  if not ok or type(Follower) ~= "table" then return end
  if Follower._stadiumFirstPartyPatched then return end

  local originalEnter = Follower.onMapEntered
  local originalUpdate = Follower.update
  if type(originalEnter) ~= "function" or type(originalUpdate) ~= "function" then
    return
  end

  local function needsProxy(game)
    local save = game and game.save
    local party = save and save.party
    local lead = type(party) == "table" and party[1] or nil
    if type(lead) ~= "table" or lead.species == nil then return false end

    -- When a healthy real Pikachu is present, Yellow's own check already
    -- passes and no temporary party entry is needed.
    for _, mon in ipairs(party) do
      if type(mon) == "table" and mon.species == "PIKACHU"
          and (mon.hp or 0) > 0 then
        return false
      end
    end
    return true
  end

  local function callWithSpawnProxy(game, fn, ...)
    if not needsProxy(game) then return fn(...) end
    local party = game.save.party
    local proxy = { species = "PIKACHU", hp = 1, _stadiumFollowerProxy = true }
    party[#party + 1] = proxy

    local result = { pcall(fn, ...) }
    -- Remove by identity in case another callback touched party order.
    for i = #party, 1, -1 do
      if party[i] == proxy then
        table.remove(party, i)
        break
      end
    end

    if not result[1] then error(result[2], 0) end
    return result[2], result[3], result[4], result[5]
  end

  Follower.onMapEntered = function(game, ow, opts, viaMapLoad)
    return callWithSpawnProxy(game, originalEnter, game, ow, opts, viaMapLoad)
  end
  Follower.update = function(game, ow)
    return callWithSpawnProxy(game, originalUpdate, game, ow)
  end
  Follower._stadiumFirstPartyPatched = true
end

installFirstPartyFollowerSpawnPatch()
local V = {
  mod = mod,
  path = mod.path,
}
setmetatable(V, { __index = BaseV })
function V.require(name)
  if name == "OverworldStadiumConfig" then return Config end
  if name == "PokemonHeights" then return PokemonHeights end
  if name == "PokemonLocomotion" then return PokemonLocomotion end
  return BaseV.require(name)
end

local Stadium = loadLocal("lib/OverworldStadium.lua", V)
V.OverworldStadium = Stadium

-- Stage 1 battle performances: exact Stadium move animations when available,
-- entrance/faint animation, and a short victim recoil without touching damage
-- calculations or the engine's own move-effect graphics.
local BattleStadiumAnimations = loadLocal("lib/BattleStadiumAnimations.lua", V)
local battleAnimationsInstalled, battleAnimationsErr = BattleStadiumAnimations.install()
if battleAnimationsInstalled then
  mod.log:info("Pokemon Stadium Stage 1 battle performances enabled")
else
  mod.log:warn("Pokemon Stadium Stage 1 battle performances not installed: %s",
               tostring(battleAnimationsErr))
end

-- Phase 2 + Phase 3 + Phase 4 battle effects: common elemental families, dedicated
-- signature-move renderers, and safe visual hit-stop/shake/impact polish
-- drawn on Gen1Recomp's own move-animation layer. Dramatic Shape already maps
-- that layer onto the 3D arena, so this does not touch battle model lifecycle.
local BattleStadiumEffects = loadLocal("lib/BattleStadiumEffects.lua", V)
local battleEffectsInstalled, battleEffectsErr = BattleStadiumEffects.install()
if battleEffectsInstalled then
  mod.log:info("Pokemon Stadium Phase 2 + Phase 3 + Phase 4 battle presentation enabled")
else
  mod.log:warn("Pokemon Stadium Phase 2 + Phase 3 + Phase 4 battle presentation not installed: %s",
               tostring(battleEffectsErr))
end

-- Phase 5: real world-space procedural effects. This wraps Dramatic Shape's
-- exported Stadium begin/update/draw functions, so the particles are drawn
-- inside the active Voxel3D scene and follow camera orbit/depth naturally.
local BattleStadium3DFx = loadLocal("lib/BattleStadium3DFx.lua", V)
local battle3DInstalled, battle3DErr = BattleStadium3DFx.install()
if battle3DInstalled then
  mod.log:info("Pokemon Stadium Phase 5 world-space battle effects enabled")
else
  mod.log:warn("Pokemon Stadium Phase 5 world-space effects not installed: %s", tostring(battle3DErr))
end

-- Patch only structural seams in the exact VoxelScene source from the installed
-- Dramatic Shape build. Stadium operations are isolated per Pokemon, so one
-- bad model falls back to its own sprite without disabling the full overlay.
local VoxelScenePatch = loadLocal("lib/VoxelScenePatch.lua", V)
local rendererInstalled, rendererErr = VoxelScenePatch.install(ds, BaseV, V, Stadium)
if rendererInstalled then
  mod.log:info("Pokemon Stadium overworld renderer installed on current Dramatic Shape VoxelScene")
else
  mod.log:warn("Stadium overworld renderer not installed; Dramatic Shape voxel renderer preserved: %s",
               tostring(rendererErr))
end

-- Companion mods can tag a Pokemon entity explicitly through this mod.
mod.exports.version = "0.1.28"
mod.exports.overworld = Stadium
mod.exports.romMenu = StadiumRomMenu
mod.exports.chooseStadiumRom = function(game)
  return StadiumRomMenu.choose(game or require("src.core.Game"))
end
mod.exports.tag = function(entity, speciesOrDex)
  return Stadium.tag(entity, speciesOrDex)
end
mod.exports.untag = function(entity)
  return Stadium.untag(entity)
end

mod.exports.rendererInstalled = rendererInstalled
mod.exports.rendererError = rendererErr
mod.exports.battleAnimationsInstalled = battleAnimationsInstalled
mod.exports.battleAnimationsError = battleAnimationsErr
mod.exports.battleEffectsInstalled = battleEffectsInstalled
mod.exports.battleEffectsError = battleEffectsErr

mod.exports.battle3DInstalled = battle3DInstalled
mod.exports.battle3DError = battle3DErr
