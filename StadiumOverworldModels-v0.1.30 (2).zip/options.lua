-- Per-mod options schema for Pokemon Stadium Overworld Models.
-- The runtime bridge turns this placeholder choice row into a file-picker action.
return {
  {
    key = "stadiumRomFile",
    type = "choice",
    label = "STADIUM ROM FILE",
    default = "choose",
    choices = {
      { "CHOOSE", "choose" },
    },
  },
}
