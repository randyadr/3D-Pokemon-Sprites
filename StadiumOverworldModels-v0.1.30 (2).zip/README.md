# Pokemon Stadium Overworld Models v0.1.30

Built directly from the stable v0.1.29 branch. This release fixes invisible 3D tornado/wind effects without changing the Stadium 3D Pokemon renderer.

## Tornado visibility fix

- Replaces the previous `love.graphics.arc` wind texture with an Android/LuaJIT-safe polyline texture. Older LÖVE signatures could silently fail that texture build, leaving tornado geometry with no texture to draw.
- Makes the tornado substantially larger and brighter.
- Uses 12 stacked world-space rings, a dense inner column, and a broad floor skirt so the funnel remains visible from different Dramatic Shape camera angles.
- Adds a generic Flying-type world-space wind fallback in addition to the explicit Gust / Whirlwind / Razor Wind / Wing Attack mappings.
- Keeps the 3D Pokemon rendering hook unchanged. No new Stadium.draw wrapper is added.

No ROM re-import is needed.
