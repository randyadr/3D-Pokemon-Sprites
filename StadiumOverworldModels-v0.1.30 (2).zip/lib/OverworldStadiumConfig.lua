-- Stadium Overworld Models configuration.
--
-- This file ships with the add-on and is loaded by lib/OverworldStadium.lua.
-- It contains NO Pokemon Stadium assets.  Dramatic Shape's existing Stadium
-- importer supplies the model packs from the player's own compatible ROM.
local Config = {}

-- Master switch for overworld replacement.
Config.enabled = true

-- Release an off-map rig after this many rendered frames.  Keeping a short
-- grace period avoids rebuilding a model when a connected-map ghost crosses
-- a seam and becomes a local entity on the next frame.
Config.staleFrames = 120

-- If an entity has no explicit Pokemon tag, allow species-specific sprite
-- names such as PIKACHU / SPRITE_PIKACHU to resolve automatically.  Generic
-- Gen 1 sheets such as MONSTER, BIRD, or BUG intentionally do not guess a
-- species because one sheet can represent several different Pokemon.
Config.autoSpriteSpecies = true

-- Pokemon Yellow's built-in follower entity is still used for its original
-- trailing movement, hiding/showing, warps, and collision behavior.  The
-- model drawn on that entity is taken LIVE from party slot #1, so changing
-- party order changes the follower without needing a map reload.
Config.firstPartyFollower = true

-- Species size mode.
--
-- v0.1.8 restores the original pre-v0.1.6 sizing by default. Dramatic Shape's
-- Stadium model worldHeight() is used directly, matching v0.1.5 and earlier.
-- Set this back to true only if you want the experimental Pokedex-relative
-- height scaling from v0.1.6/v0.1.7.
Config.pokedexScale = false

-- Human reference used to turn metres into overworld world-pixels. A Pokemon
-- whose Pokedex height equals `humanReferenceMeters` will be this many world
-- pixels tall. 24 px is 1.5 overworld tiles and matches the visual scale of
-- the 3D trainer reasonably well while still letting giants feel giant.
Config.humanReferenceMeters = 1.60
Config.humanReferenceWorldHeight = 24

-- Global multiplier after Pokedex scaling. Leave at 1 for the canonical
-- Pokemon:human ratio. If the whole cast feels too large/small, change only
-- this value (for example 0.85 or 1.15).
Config.pokedexScaleMultiplier = 1.0

-- Optional per-Dex multipliers for artistic/camera exceptions. These are
-- applied AFTER canonical height scaling. Example: [95] = 0.8 for Onix.
Config.heightOverrides = {}

-- Safety clamps in world pixels. `nil` means no clamp, preserving the actual
-- relative height ratio even for Onix/Gyarados. Set maxPokemonWorldHeight if
-- you prefer the biggest Pokemon to stay inside the camera more often.
Config.minPokemonWorldHeight = 3
Config.maxPokemonWorldHeight = nil

-- Grounded biped walking locomotion (v0.1.7).
--
-- The Stadium battle assets do not provide one universal named walk clip.
-- For grounded two-legged species the overworld renderer uses that species'
-- alternate standby loop when available, synchronizes it to actual distance
-- travelled, and adds a subtle footfall bob/pitch. Flying/hovering Pokemon and
-- quadrupeds retain their existing Stadium animation.
Config.walkingAnimations = true

-- Global gait speed. 1.0 is tuned to Gen 1 overworld movement. Higher values
-- make feet cycle faster for the same distance travelled.
Config.walkCadenceMultiplier = 1.0

-- Body-motion multipliers for the procedural ground-contact portion. Set bob
-- to 0 if you want only the Stadium skeletal loop, or pitch to 0 to remove the
-- slight forward/back weight shift while preserving the step cycle.
Config.walkBobMultiplier = 1.0
Config.walkPitchMultiplier = 1.0

-- Per-Dex grounded-biped classification overrides. Use true to opt a species
-- in, false to opt one out without editing PokemonLocomotion.lua.
-- Example: Config.walkSpeciesOverrides = { [52] = false, [123] = true }
Config.walkSpeciesOverrides = {}

-- Optional exact overrides for old maps/mods whose Pokemon NPCs carry only a
-- generic overworld sprite and no species metadata.
--
-- Keys are map IDs.  Inside a map, key by entity index or by entity name/id.
-- Values may be a National Dex number or an engine species key.
--
-- Example:
-- Config.overrides = {
--   SOME_MAP = {
--     [3] = 25,
--     PIKACHU_FOLLOWER = "PIKACHU",
--   },
-- }
Config.overrides = {}

return Config
