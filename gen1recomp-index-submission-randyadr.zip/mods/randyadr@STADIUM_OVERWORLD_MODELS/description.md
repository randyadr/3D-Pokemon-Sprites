# Pokemon Stadium Overworld Models

Pokemon Stadium Overworld Models is a presentation mod for Gen1Recomp that uses Dramatic Shape's locally imported Pokemon Stadium model data to render Pokemon as 3D models in the overworld and in compatible battle scenes.

## Highlights

- 3D Stadium models for identified overworld Pokemon
- Followers EX integration with configurable follower count
- Non-Flying walking / waddle locomotion
- Curated size tuning for small and large Pokemon
- Stadium battle integration with procedural battle effects
- 3D wind funnels and branching Electric effects
- Android Stadium ROM file picker
- Dramatic Sky Ride compatibility
- Reflection and shadow support through Dramatic Shape where available

## Requirements

The mod requires **Dramatic Shape** (`DRAMATIC_SHAPE`). Pokemon Stadium model data is not included. The player supplies their own compatible Pokemon Stadium ROM and imports the data locally.

Followers EX and Dramatic Sky Ride are optional integrations.

## Distribution

This repository does not distribute a Pokemon Stadium ROM or extracted Nintendo model assets. Release ZIPs contain only the mod code/configuration and are installable directly through Gen1Recomp's mod manager.
